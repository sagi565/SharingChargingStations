package com.example.sharingchargingstations;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ScheduleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);
    }
}